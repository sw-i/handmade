const { GoogleGenerativeAI } = require('@google/generative-ai');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const systemInstruction = `System Instructions (for Gemini Chatbot):

You are a helpful, knowledgeable, and supportive assistant for the Handmade Hub SaaS platform.

Your primary users are home-based entrepreneurs, small artisans, and event vendors seeking to manage their e-commerce products, events, sales, and community engagement effectively.

Provide clear, concise, and step-by-step guidance on using the platform, including product listings, order management, event participation, registration, business analytics, and secure payment processes.

Proactively alert users to important system information such as GDPR compliance, payment safety, and best practices for protecting their digital identity.

Never disclose user-sensitive data and always reinforce modern standards of privacy, fairness, and accessibility.

When users inquire about features, explain step-by-step without jargon, and offer additional context if the user expresses confusion or is a new entrepreneur.

Offer encouragement, reassure users when they encounter setbacks, and celebrate their platform achievements (like successful event registrations or new product launches).

If a problem exceeds your scope, prompt users to contact Handmade Hub support for further assistance.

Optional Tone and Style Instructions:

Use a warm, positive, and inclusive tone; sound like a partner who understands the unique challenges of artisans and small business owners.

Be empowering and motivational, especially for users new to digital platforms or online sales.

Keep answers practical, action-oriented, and free from technical jargon.

Use short paragraphs, bullet points, and simple examples when explaining complex tasks or processes.

Balance professionalism with approachability—avoid humor or slang, but remain personable and encouraging.

Reinforce Handmade Hub's mission to support community growth, ethical business, and digital inclusion in all guidance.

Keep answers concise, actionable, and warm.`;

// @desc    Chat with AI assistant
// @route   POST /api/chat
// @access  Public
exports.chat = async (req, res) => {
  try {
    const { message, conversationHistory } = req.body;

    if (!message) {
      return res.status(400).json({ message: 'Message is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ 
        message: 'AI service is not configured. Please contact support.' 
      });
    }

    const model = genAI.getGenerativeModel({ 
      model: 'gemini-2.0-flash-exp',
      systemInstruction: systemInstruction
    });

    // Build chat history - ensure it starts with user role
    const history = [];
    if (conversationHistory && Array.isArray(conversationHistory)) {
      conversationHistory.forEach((msg, index) => {
        // Skip if first message is not from user
        if (index === 0 && msg.role !== 'user') return;
        
        history.push({
          role: msg.role === 'user' ? 'user' : 'model',
          parts: [{ text: msg.content }]
        });
      });
    }

    // Start chat with history
    const chat = model.startChat({ history });

    // Set headers for streaming
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Transfer-Encoding', 'chunked');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    // Send message and stream response
    const result = await chat.sendMessageStream(message);

    // Stream the response chunks
    for await (const chunk of result.stream) {
      const chunkText = chunk.text();
      if (chunkText) {
        res.write(chunkText);
      }
    }

    res.end();
  } catch (error) {
    console.error('Chat error:', error);
    
    // If streaming hasn't started, send JSON error
    if (!res.headersSent) {
      res.status(500).json({ 
        message: 'Failed to get AI response. Please try again.',
        error: process.env.NODE_ENV === 'development' ? error.message : undefined
      });
    } else {
      // If streaming started, just end the response
      res.end();
    }
  }
};

// @desc    Chat with AI assistant (non-streaming for simpler clients)
// @route   POST /api/chat/simple
// @access  Public
exports.chatSimple = async (req, res) => {
  try {
    const { message, conversationHistory } = req.body;

    if (!message) {
      return res.status(400).json({ message: 'Message is required' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ 
        message: 'AI service is not configured. Please contact support.' 
      });
    }

    const model = genAI.getGenerativeModel({ 
      model: 'gemini-2.0-flash-exp',
      systemInstruction: systemInstruction
    });

    // Build chat history - ensure it starts with user role
    const history = [];
    if (conversationHistory && Array.isArray(conversationHistory)) {
      conversationHistory.forEach((msg, index) => {
        // Skip if first message is not from user
        if (index === 0 && msg.role !== 'user') return;
        
        history.push({
          role: msg.role === 'user' ? 'user' : 'model',
          parts: [{ text: msg.content }]
        });
      });
    }

    // Start chat with history
    const chat = model.startChat({ history });

    // Send message and get response
    const result = await chat.sendMessage(message);
    const responseText = result.response.text();

    res.json({ 
      response: responseText,
      success: true
    });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ 
      message: 'Failed to get AI response. Please try again.',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
};
