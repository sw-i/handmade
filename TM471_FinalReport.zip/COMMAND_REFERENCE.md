# Quick Command Reference

## 🚀 Start/Stop Platform

```powershell
# Start all services
docker-compose up -d

# Start with rebuild
docker-compose up -d --build

# Stop all services
docker-compose down

# Stop and remove volumes (CAUTION: deletes database data!)
docker-compose down -v
```

## 📊 Check Status

```powershell
# View running containers
docker-compose ps

# Check container health
docker-compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}"

# Test API health
Invoke-RestMethod -Uri "http://localhost:5000/api/v1/health"

# Test frontend
Invoke-WebRequest -Uri "http://localhost:3000" -UseBasicParsing
```

## 📝 View Logs

```powershell
# All services (follow mode)
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f mysql

# Last 50 lines
docker logs handmade-hub-backend --tail=50
```

## 🗄️ Database Operations

```powershell
# Access MySQL CLI
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub

# Run a query
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "SELECT * FROM users;"

# Backup database
docker-compose exec mysql mysqldump -uhandmade_user -phandmade_password123 handmade_hub > backup.sql

# Restore database
Get-Content backup.sql | docker-compose exec -T mysql mysql -uhandmade_user -phandmade_password123 handmade_hub
```

## 🧪 Test API Endpoints

### Register
```powershell
$body = @{
    email = 'test@example.com'
    password = 'Test123!'
    firstName = 'Test'
    lastName = 'User'
    role = 'customer'
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:5000/api/v1/auth/register" `
    -Method POST `
    -ContentType "application/json" `
    -Body $body
```

### Login
```powershell
$body = @{
    email = 'test@example.com'
    password = 'Test123!'
} | ConvertTo-Json

$response = Invoke-RestMethod -Uri "http://localhost:5000/api/v1/auth/login" `
    -Method POST `
    -ContentType "application/json" `
    -Body $body

$token = $response.token
```

### Get Products
```powershell
Invoke-RestMethod -Uri "http://localhost:5000/api/v1/products?limit=10"
```

### Get Single Product
```powershell
Invoke-RestMethod -Uri "http://localhost:5000/api/v1/products/{id}"
```

### Create Product (Requires Authentication)
```powershell
$headers = @{
    Authorization = "Bearer $token"
    "Content-Type" = "application/json"
}

$body = @{
    title = 'Handmade Ceramic Mug'
    description = 'Beautiful handmade ceramic mug'
    price = 29.99
    stockQuantity = 10
    categoryId = '{category-uuid}'
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:5000/api/v1/products" `
    -Method POST `
    -Headers $headers `
    -Body $body
```

## 🔧 Container Management

```powershell
# Restart a service
docker-compose restart backend

# Rebuild a specific service
docker-compose build backend
docker-compose up -d backend

# Execute command in container
docker-compose exec backend node --version
docker-compose exec frontend npm --version

# Access container shell
docker-compose exec backend sh
docker-compose exec mysql bash
```

## 🧹 Cleanup

```powershell
# Remove stopped containers
docker-compose rm

# Prune unused Docker resources
docker system prune

# Prune with volumes (CAUTION!)
docker system prune -a --volumes

# Remove specific container
docker-compose stop backend
docker-compose rm backend
```

## 🔍 Debugging

```powershell
# Check Docker network
docker network ls
docker network inspect handmade-hub-network

# Check volumes
docker volume ls
docker volume inspect 1_mysql-data

# Inspect container
docker inspect handmade-hub-backend

# Check resource usage
docker stats
```

## 📦 Update Code

```powershell
# After modifying backend code
docker-compose build backend
docker-compose up -d backend

# After modifying frontend code
docker-compose build frontend
docker-compose up -d frontend

# Rebuild everything
docker-compose down
docker-compose up -d --build
```

## 🔐 User Management

### Update User Role
```powershell
# Make user an admin
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "UPDATE users SET role='admin' WHERE email='test@example.com';"

# Make user a vendor
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "UPDATE users SET role='vendor' WHERE email='test@example.com';"
```

### Reset User Password
```powershell
# Generate new password hash (run in backend container)
docker-compose exec backend node -e "const bcrypt = require('bcryptjs'); bcrypt.hash('NewPassword123!', 12).then(hash => console.log('Hash:', hash));"

# Update password in database
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "UPDATE users SET password='{hash}' WHERE email='test@example.com';"
```

## 📊 Database Queries

```powershell
# Count users
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "SELECT role, COUNT(*) as count FROM users GROUP BY role;"

# List all products
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "SELECT id, title, price, stock_quantity FROM products;"

# List all orders
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "SELECT id, order_number, total_amount, status FROM orders;"

# Check vendor approvals
docker-compose exec mysql mysql -uhandmade_user -phandmade_password123 handmade_hub -e "SELECT business_name, is_approved FROM vendors;"
```

## 🌐 URLs

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **API Docs**: http://localhost:5000/api/v1
- **Health Check**: http://localhost:5000/api/v1/health

## 🚨 Emergency Commands

```powershell
# Kill all running containers
docker-compose kill

# Force remove all containers
docker-compose down --remove-orphans

# Reset everything (NUCLEAR OPTION!)
docker-compose down -v
docker system prune -a --volumes -f
docker-compose up -d --build
```

## ⚡ Performance

```powershell
# Check container resource usage
docker stats --no-stream

# Check logs size
docker-compose exec backend du -sh /app/logs/*

# Clear logs
docker-compose exec backend sh -c "truncate -s 0 /app/logs/*.log"
```

---

**Tip**: Create PowerShell aliases for frequently used commands:

```powershell
# Add to your PowerShell profile
Set-Alias dc docker-compose
function dcup { docker-compose up -d }
function dcdown { docker-compose down }
function dclogs { docker-compose logs -f $args }
function dcps { docker-compose ps }
```

Then use: `dc ps`, `dcup`, `dcdown`, `dclogs backend`
